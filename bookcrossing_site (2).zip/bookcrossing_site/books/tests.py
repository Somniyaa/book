from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User
from books.models import Book
from django.contrib.auth import get_user_model
User = get_user_model()

class BookIntegrationTest(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='testpass')
        self.client.login(username='testuser', password='testpass')

    def test_book_release_form_submission(self):
        url = reverse('release_book')  

        form_data = {
            'title': 'Тестовая книга',
            'author': 'Тестовый автор',
            'genre': 'роман',
            'comment': 'Оставил на лавочке',
        }

        response = self.client.post(url, data=form_data, follow=True)

        self.assertEqual(Book.objects.count(), 1)

        book = Book.objects.first()
        self.assertEqual(book.title, 'Тестовая книга')
        self.assertEqual(book.location, 'Парк Гагарина')
        self.assertEqual(book.status, 'released')  

        self.assertTemplateUsed(response, 'books/release_book.html')
