from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import custom_logout_view, custom_login_view

urlpatterns = [
    path('', views.index, name='home'), 
    path('points/', views.points_view, name='points'),
    path('catalog/', views.catalog, name='catalog'),
    path('about/', views.about_view, name='about'),
    path('register/', views.register_view, name='register'),
    path('login/', custom_login_view, name='login'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('profile/', views.profile, name='profile'),
    path('add_book/', views.add_book, name='add_book'),
    path('logout/', custom_logout_view, name='logout'),
    path('take-book/<int:book_id>/', views.take_book, name='take_book'),
    path('edit-book/<int:book_id>/', views.edit_book, name='edit_book'),
    path('delete-book/<int:book_id>/', views.delete_book, name='delete_book'),
    path('take-book/<int:book_id>/', views.take_book, name='take_book'),
    path('release/<int:book_id>/', views.release_book, name='release_book'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

