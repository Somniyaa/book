from django.contrib.auth.models import AbstractUser, Group, Permission
from django.db import models
from django.conf import settings

class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    avatar = models.ImageField(upload_to='profile_pics/', null=True, blank=True)
    date_joined = models.DateTimeField(auto_now_add=True)

    def str(self):
        return self.username
    
class Point(models.Model):
    name = models.CharField(max_length=100)
    address = models.CharField(max_length=255)
    district = models.CharField(max_length=100)
    latitude = models.FloatField()
    longitude = models.FloatField()

    def str(self):
        return self.name 


class UserProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    bio = models.TextField(blank=True, null=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)  
    
    def str(self):
        return self.user.username
    
    
class Book(models.Model):
    STATUS_CHOICES = [
        ('added', 'Добавлена'),
        ('released', 'Отпущена'),
        ('found', 'Найдена'),
    ]

    GENRE_CHOICES = [
        ('роман', 'Роман'),
        ('фэнтези', 'Фэнтези'),
        ('детектив', 'Детектив'),
        ('научная фантастика', 'Научная фантастика'),
        ('классика', 'Классика'),
        ('триллер', 'Триллер'),
        ('ужасы', 'Ужасы'),
        ('современная проза', 'Современная проза'),
        ('историческая проза', 'Историческая проза'),
        ('поэзия', 'Поэзия'),
        ('нон-фикшн', 'Нон-фикшн'),
        ('другое', 'Другое'),
    ]

    title = models.CharField(max_length=200)
    author = models.CharField(max_length=200)
    genre = models.CharField(max_length=50, choices=GENRE_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='added')
    cover = models.ImageField(upload_to='book_covers/', blank=True, null=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    taken_by = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.SET_NULL,null=True,blank=True,related_name='taken_books')
    date_added = models.DateTimeField(auto_now_add=True)
    release_date = models.DateTimeField(blank=True, null=True)
    date_found = models.DateTimeField(blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    location = models.CharField(max_length=255, blank=True, null=True)
    def str(self):
        return self.title