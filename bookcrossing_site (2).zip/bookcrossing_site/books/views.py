from django.shortcuts import render, redirect
from .models import Point, Book
from django.contrib.auth import login
from .forms import CustomUserCreationForm
from django.contrib.auth import authenticate, login, get_user
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .forms import UserProfileForm
from django.contrib.auth import get_user_model
from .forms import BookForm
from django.contrib.auth import logout
from .models import UserProfile
from django.shortcuts import get_object_or_404
from django.contrib import messages
from django import forms
from .forms import ReleaseBookForm
from django.utils import timezone
User = get_user_model()

@login_required
def profile(request):
    user = request.user
    added_books = Book.objects.filter(user=user, status='added')
    released_books = Book.objects.filter(user=user, status='released')
    taken_books = Book.objects.filter(status='found', user=user)

    if request.method == 'POST' and 'avatar' in request.FILES:
        user.avatar = request.FILES['avatar']
        user.save()

    return render(request, 'profile.html', {
        'user': user,
        'added_books': added_books,
        'released_books': released_books,
        'taken_books': taken_books,
    })
        
        

def index(request):
    return render(request, 'home.html')

def points_view(request):
    points = Point.objects.all()
    return render(request, 'points.html', {'points': points})

def about_view(request):
    return render(request, 'about.html')

def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  
            return redirect('profile') 
    else:
        form = CustomUserCreationForm()

    return render(request, 'register.html', {'form': form})
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('profile')  
        else:
            messages.error(request, 'Неверное имя пользователя или пароль')

    return render(request, 'profile.html')

def edit_profile(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=request.user.profile)
        if form.is_valid():
            form.save()
            return redirect('profile') 
    else:
        form = UserProfileForm(instance=request.user.profile)

    return render(request, 'edit_profile.html', {'form': form})


@login_required
def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            book = form.save(commit=False)
            book.user = User.objects.get(id=request.user.id)
            book.save()
            return redirect('profile')  
    else:
        form = BookForm()
    return render(request, 'add_book.html', {'form': form})


@login_required
def take_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if book.status == 'released':
        book.status = 'found'
        book.taken_by = request.user
        book.save()
    return redirect(request.META.get('HTTP_REFERER', '/'))
def catalog(request):

    books = Book.objects.all().order_by('-date_added', '-release_date')

    title = request.GET.get('title')
    author = request.GET.get('author')
    genre = request.GET.get('genre')
    status = request.GET.get('status')


    if title:
        books = books.filter(title__icontains=title)
    if author:
        books = books.filter(author__icontains=author)
    if genre:
        books = books.filter(genre__iexact=genre)
    if status:
        books = books.filter(status=status)
    return render(request, 'catalog.html', {'books': books})

@login_required
def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id, user=request.user)
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = BookForm(instance=book)
    return render(request, 'edit_book.html', {'form': form})

@login_required
def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'GET':
        book.delete()
        return redirect('profile')
   
   
@login_required
def take_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if book.status == 'released':
        book.status = 'found'
        book.user = request.user  
        book.save()
    return redirect('catalog')

def custom_logout_view(request):
    logout(request)
    return redirect('/')  


class LoginForm(forms.Form):
    username = forms.CharField(label='Имя пользователя')
    password = forms.CharField(widget=forms.PasswordInput, label='Пароль')

def custom_login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password']
            )
            if user is not None:
                login(request, user)
                return redirect('/profile/')  
            else:
                messages.error(request, 'Неверное имя пользователя или пароль')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

@login_required
def release_book(request, book_id):
    book = get_object_or_404(Book, id=book_id, user=request.user, status='added')
    
    if request.method == 'POST':
        form = ReleaseBookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            book = form.save(commit=False)
            book.status = 'released'
            book.release_date = timezone.now()
            book.save()
            return redirect('profile')  
    else:
        form = ReleaseBookForm(instance=book)

    return render(request, 'release_book.html', {'form': form, 'book': book})